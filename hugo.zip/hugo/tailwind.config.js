module.exports = {
  content: [
    "./layouts/**/*.html",
    "./layouts/index.html",
    "./layouts/_default/*.html",
    "./layouts/partials/*.html"
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}

